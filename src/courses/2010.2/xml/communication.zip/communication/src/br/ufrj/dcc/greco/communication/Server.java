package br.ufrj.dcc.greco.communication;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


class Server implements Runnable {

	private Connector callback;
	private ServerSocket serverSocket;
	
	Server(Connector callback, int port) throws IOException {
		this.callback = callback; 
		serverSocket = new ServerSocket(port);
	}

	public void run() {
		try {
			while (true) {
				Socket socket = serverSocket.accept();
				Thread thread = new Thread(new Connection(callback, socket));
				thread.start();
			} 
		} catch (IOException e) {
			callback.reportException(e);
		}
	}

}
