package br.ufrj.dcc.greco.communication;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

class Connection implements Runnable {

	private Connector callback;
	private Socket socket;
	
	Connection(Connector callback, Socket socket) {
		this.callback = callback;
		this.socket = socket;
	}

	public void run() {
		try {
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			StringBuffer stringBuffer = new StringBuffer();
			char[] buffer = new char[64 * 1024];
			
			int length = bufferedReader.read(buffer);
			while (length != -1) {
				stringBuffer.append(buffer, 0, length);
				length = bufferedReader.read(buffer);
			}
			
			callback.receive(stringBuffer.toString());
		} catch (Exception e) {
			callback.reportException(e);
		}
	}
}
