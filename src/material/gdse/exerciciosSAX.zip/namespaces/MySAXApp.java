import java.io.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParserFactory; 
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser; 


public class MySAXApp extends DefaultHandler { 

public MySAXApp () { 
	super(); 
} 

public static void main (String argv[]) throws Exception { 

  if (argv.length != 1) {
    System.err.println("Modo de usar: MySAXApp <nome do arquivo XML>");
    System.exit(1);
  } 
  // Usa uma inst�ncia da propria classe como o gerenciador de eventos SAX
  DefaultHandler handler = new MySAXApp();
 
  // Usa o parsing default (sem valida��o)
  SAXParserFactory factory = SAXParserFactory.newInstance();

  //Vejam a diferen�a no resultado do processamento com e sem esta linha abaixo
  factory.setNamespaceAware(true);

  try {
 
    // Faz o parsing
    SAXParser saxParser = factory.newSAXParser();
    System.out.println(saxParser.isNamespaceAware());

    saxParser.parse( new File(argv[0]), handler ); 
  } catch (Throwable t) {
    t.printStackTrace();
  }
  System.exit(0);

} 

public void startElement (String uri, String localName, String qName, Attributes atts) {

    System.out.println("qName = " + qName);
    System.out.println("localName = " + localName);
    System.out.println("uri = " + uri);

}

} 
