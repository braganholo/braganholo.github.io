
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;
import org.w3c.dom.Node;

public class ProcessaSQLDOM {

    static public void main(String[] argv) {
        try {
            if (argv.length != 1) {
                // Must pass in the name of the XML file.
                System.err.println("Usage: java ProcessaSQLDOM filename");
                System.exit(1);
            }

            // Get an instance of the parser			
            DocumentBuilderFactory b = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = b.newDocumentBuilder();

            // Parse the document
            Document myDoc = builder.parse(argv[0]);
            //Processa pedido
            processaSQL(myDoc);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    static void processaSQL(Document doc) {
        int i;
        //Recupera SQLs
        Element raiz = doc.getDocumentElement();
        examinaFilhos((Node) raiz);
    }

    static void examinaFilhos(Node n) {
        int i;
        if (n.hasChildNodes()) {
            NodeList filhos = n.getChildNodes();
            for (i = 0; i < filhos.getLength(); i++) {
                examinaFilhos(filhos.item(i));
            }
        }
    }
}
