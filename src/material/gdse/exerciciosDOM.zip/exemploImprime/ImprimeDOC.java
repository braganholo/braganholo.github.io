
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.w3c.dom.*;
import org.w3c.dom.Node;

public class ImprimeDOC {

    static public void main(String[] argv) {
        try {
            if (argv.length != 1) {
                // Must pass in the name of the XML file.
                System.err.println("Usage: java ImprimeDOC filename");
                System.exit(1);
            }

            // Get an instance of the parser			
            DocumentBuilderFactory b = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = b.newDocumentBuilder();

            // Parse the document
            Document myDoc = builder.parse(argv[0]);
            //Imprime Documento
            imprime(myDoc);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    static void imprime(Node myDoc) {
        try {

            // configura o transformador
            TransformerFactory transfac = TransformerFactory.newInstance();
            Transformer trans = transfac.newTransformer();
            trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            trans.setOutputProperty(OutputKeys.INDENT, "yes");

            // cria uma string a partir da �rvore XML
            StringWriter sw = new StringWriter();
            StreamResult result = new StreamResult(sw);
            DOMSource source = new DOMSource(myDoc);
            trans.transform(source, result);
            String xmlString = sw.toString();

            // imprime o XML
            System.out.println("Aqui esta o xml:\n\n" + xmlString);
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
