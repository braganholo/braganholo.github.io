
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ProcessaDocumentoDOM {

    static public void main(String[] argv) {
        try {
            if (argv.length != 1) {
                // Must pass in the name of the XML file.
                System.err.println("Usage: java ProcessaDocumentoDOM filename");
                System.exit(1);
            }

            // Get an instance of the parser			
            DocumentBuilderFactory b = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = b.newDocumentBuilder();

            //Parse the document
            Document myDoc = builder.parse(argv[0]);

            //Processa documento
            processa(myDoc);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    static void processa(Document doc) {
        int i;
        //Recupera elementos
        Element raiz = doc.getDocumentElement();
        imprimeFilhos((Node) raiz);
    }

    static void imprimeFilhos(Node n) {
        int i;
        System.out.print(n.getNodeName() + "=>" + n.getNodeValue() + " ");

        if (n.hasChildNodes()) {
            NodeList filhos = n.getChildNodes();
            for (i = 0; i < filhos.getLength(); i++) {
                imprimeFilhos(filhos.item(i));
            }
        }
    }
}
