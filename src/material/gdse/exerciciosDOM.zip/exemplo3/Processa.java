
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class Processa {

    static public void main(String[] argv) {
        try {
            if (argv.length != 1) {
                // Must pass in the name of the XML file.
                System.err.println("Usage: java Processa filename");
                System.exit(1);
            }

            // Get an instance of the parser			
            DocumentBuilderFactory b = DocumentBuilderFactory.newInstance();

            //Seta valida��o para true
            b.setValidating(true);

            DocumentBuilder builder = b.newDocumentBuilder();

            //Pega uma inst�ncia do manipulador de erros
            MeuManipuladorDeErros handler = new MeuManipuladorDeErros();
            //Seta o ErrorHandler
            builder.setErrorHandler(handler);

            //Parse the document
            Document myDoc = builder.parse(argv[0]);

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
