
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;
import org.w3c.dom.Node;

public class ProcessaPedidoDOM {

    static public void main(String[] args) {
        try {
            if (args.length != 1) {
                // Must pass in the name of the XML file.
                System.err.println("Usage: java DOMSample filename");
                System.exit(1);
            }

            // Get an instance of the parser			
            DocumentBuilderFactory b = DocumentBuilderFactory.newInstance();
            b.setIgnoringElementContentWhitespace(true);
            DocumentBuilder builder = b.newDocumentBuilder();

            //Parse the document
            Document myDoc = builder.parse(args[0]);
            //Processa pedido
            processaPedido(myDoc);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    static void processaPedido(Document doc) {
        int i, j;
        System.out.println("*********************************");

        //Recupera Cliente
        NodeList lista_razao_social = doc.getElementsByTagName("razao_social");
        //O texto do elemento � um nodo filho de razao_social
        Node n = lista_razao_social.item(0).getFirstChild();
        System.out.println("--> Cliente: " + n.getNodeValue());

        //Calcula Valor total
        int total_pedido = 0;
        String quant = "";
        String preco = "";

        NodeList lista_itens = doc.getElementsByTagName("item");
        for (i = 0; i < lista_itens.getLength(); i++) {
            //Percorre os filhos do item atual 
            NodeList filhos_item = lista_itens.item(i).getChildNodes();
            j = 0;
            while (j < filhos_item.getLength()) {
                if ((filhos_item.item(j).getNodeType() == Node.ELEMENT_NODE)
                        && (filhos_item.item(j).getNodeName().equals("quantidade"))) {
                    //O valor do nodo � um filho		
                    quant = filhos_item.item(j).getFirstChild().getNodeValue();
                }

                if ((filhos_item.item(j).getNodeType() == Node.ELEMENT_NODE)
                        && (filhos_item.item(j).getNodeName().equals("preco_unit"))) {
                    preco = filhos_item.item(j).getFirstChild().getNodeValue();
                }
                j++;
            }
            total_pedido = total_pedido + (Integer.parseInt(preco) * Integer.parseInt(quant));
        }
        System.out.println("--> Valor Total: " + total_pedido);
        System.out.println("*********************************");

    }
}
