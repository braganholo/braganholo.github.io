#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arvore-b.h"

TNo *cria(int d) {
    TNo *novo = (TNo *) malloc(sizeof(TNo));
    novo->m = 0;
    novo->pai = NULL;
    novo->s = (int *) malloc(sizeof(int *) * (d * 2));
    novo->p = (TNo **) malloc(sizeof(TNo *) * (d * 2 + 1));
    for (int i = 0; i < (d * 2 + 1); i++) {
        novo->p[i] = NULL;
    }
    return novo;
}

TNo *libera(TNo *a, int d) {
    if (a != NULL) {
        for (int i = 0; i <= a->m; i++) { // um nó tem m+1 filhos válidos (índices 0..m)
            libera(a->p[i], d);
        }
        free(a->s);
        free(a->p);
        free(a);
    }
    return NULL;
}

/*
 * A impressao da árvore é feita como se ela estivesse na vertical ao invés da horizontal, portanto cada nó é impresso na vertical,
 * com a menor chave do nó na parte inferior do nó
 */
void imprime_arvore(TNo *a, int nivel) {
    if (a != NULL) {
        char indent[10] = "";
        for (int i = 0; i < nivel; i++) {
            strcat(indent, "\t");
        }

        for (int i = a->m; i > 0; i--) {
            imprime_arvore(a->p[i], nivel + 1);
            printf("%s", indent);
            printf("%5d\n", a->s[i - 1]);
        }
        imprime_arvore(a->p[0], nivel + 1);
    }
}

void imprime_no(TNo *a) {
    if (a != NULL) {
        for (int i = 0; i < a->m; i++) {
            printf("%5d", a->s[i]);
        }
        printf("\n");
    }
}

/*
 * Busca binária da posição em que a chave deveria estar dentro do nó.
 */
int posicao(int chave, TNo *no) {
    int inicio = 0;
    int fim = no->m;
    int pos = (fim + inicio) / 2;
    while (pos != no->m && chave != no->s[pos] && inicio < fim) {
        if (chave > no->s[pos]) {
            inicio = pos + 1;
        } else {
            fim = pos;
        }
        pos = (fim + inicio) / 2;
    }
    return pos;
}

/*
 * Busca retorna ponteiro para o nó onde a chave está, ou onde ela deveria estar (se chegar numa folha e não encontrar a chave)
 */
TNo *busca(TNo *no, int chave) {
    int pos = posicao(chave, no);
    if (no->p[pos] == NULL || (pos < no->m && chave == no->s[pos])) {
        return no;
    } else {
        return busca(no->p[pos], chave);
    }
}

void particiona(TNo *P, int d, int pos, int chave, TNo *pt);

/*
 * Insere a chave e o seu repectivo ponteiro da direita (para Q) numa posição específica de um nó específico da árvore
 * d é a ordem da arvore
 * Caso a posição não seja informada (-1) o algoritmo busca pela posição correta
 * Retorna ponteiro para a raiz da árvore
 */
void insere(TNo *no, int d, int pos, int chave, TNo *pt) {
    if (pos == -1) {
        pos = posicao(chave, no);
    }

    if (no->m < 2 * d) { // Tem espaço no nó, então pode inserir diretamente
        for (int i = no->m; i > pos; i--) { // Abre espaço para a inserção
            no->s[i] = no->s[i - 1];
            no->p[i + 1] = no->p[i];
        }
        no->s[pos] = chave;
        no->p[pos + 1] = pt;
        if (pt != NULL) {
            pt->pai = no;
        }
        no->m++;
    } else { // Nó está cheio -- é necessário particionar
        particiona(no, d, pos, chave, pt);
    }
}

/*
 * Insere a chave numa folha da árvore
 * raiz é ponteiro para a raiz da árvore
 * d é a ordem da arvore
 * Retorna ponteiro para a raiz da árvore
 */
TNo *insere_folha(TNo *raiz, int d, int chave) {
    if (raiz != NULL) {
        TNo *no = busca(raiz, chave);
        int pos = posicao(chave, no);
        if (pos == no->m || chave != no->s[pos]) { // chave não existe no nó
            insere(no, d, pos, chave, NULL);
            if (raiz->pai != NULL) { // Inserção riou uma nova raiz
                raiz = raiz->pai;
            }
        }
    } else {
        raiz = cria(d);
        raiz->s[0] = chave;
        raiz->m = 1;
    }
    return raiz;
}

/*
 * Particiona o nó P para adicionar a chave e o ponteiro pt
 * Após o final da execução dessa função, a chave terá sido inserida no local correto
 * e um novo nó Q terá sido criado como resultado do particionamento
 * Uma nova raiz W pode ser criada, se a raiz atual estiver sendo particionada
 */
void particiona(TNo *P, int d, int pos, int chave, TNo *pt) {
    // Prepara Q
    TNo *Q = cria(d);
    int i = d * 2 - 1;
    int j = d - 1;
    while (j >= 0) {
        if (j != pos - d - 1) { // Move chave de P para Q
            Q->s[j] = P->s[i];
            Q->p[j + 1] = P->p[i + 1];
            i--;
        } else { // Insere chave em Q
            Q->s[j] = chave;
            Q->p[j + 1] = pt;
        }
        if (Q->p[j + 1] != NULL) {
            Q->p[j + 1]->pai = Q;
        }
        j--;
    }
    Q->m = d;

    // Processa P
    if (pos <= d) {
        P->m = d;
        insere(P, d, pos, chave, pt); // inserção vai fazer o número de chaves aumentar para d+1, e isso é tratado no final dessa função
    }

    // Processa W
    if (P->pai == NULL) { // Caso o nó seja raiz, cria o nó superior
        TNo *W = cria(d);
        W->p[0] = P;
        P->pai = W;
    }
    // Chave d de P sobe para o pai W
    insere(P->pai, d, -1, P->s[d], Q);
    // Ajusta o ponteiro da esquerda de Q (recebe ponteiro da direita da chave que subiu para o pai W)
    Q->p[0] = P->p[d+1];
    // Se o ponteiro p[0] for diferente de NULL, ajusta o ponteiro do pai do nó apontado por p[0[
    if (Q->p[0] != NULL)
        Q->p[0]->pai = Q;
    // A inserção da chave d em W fez o número de chaves de P diminuir para D
    P->m = d;
}

/*
 * Retorna 1 se o nó é folha (não possui filhos) e 0 caso contrário.
 * Numa árvore B um nó ou tem todos os filhos ou nenhum, então basta testar p[0].
 */
int eh_folha(TNo *no) {
    return no->p[0] == NULL;
}

/*
 * Redistribuição com o irmão da ESQUERDA.
 * O nó 'no' (que sofreu underflow) está em pai->p[idx] e o irmão esquerdo em pai->p[idx-1].
 * A chave separadora (pai->s[idx-1]) desce para o início de 'no' e a maior chave do
 * irmão esquerdo sobe para ocupar o lugar do separador no pai. O filho mais à direita do
 * irmão passa a ser o filho mais à esquerda de 'no'.
 */
void redistribui_esquerda(TNo *pai, int idx, TNo *no, TNo *esq) {
    int i;
    // Abre espaço no início de 'no' (desloca chaves e ponteiros uma posição à direita)
    for (i = no->m; i > 0; i--) {
        no->s[i] = no->s[i - 1];
    }
    for (i = no->m + 1; i > 0; i--) {
        no->p[i] = no->p[i - 1];
    }
    // O separador desce do pai para o início de 'no'
    no->s[0] = pai->s[idx - 1];
    // O filho mais à direita do irmão esquerdo passa a ser o p[0] de 'no'
    no->p[0] = esq->p[esq->m];
    if (no->p[0] != NULL) {
        no->p[0]->pai = no;
    }
    no->m++;
    // A maior chave do irmão esquerdo sobe para o pai
    pai->s[idx - 1] = esq->s[esq->m - 1];
    esq->p[esq->m] = NULL;
    esq->m--;
}

/*
 * Redistribuição com o irmão da DIREITA.
 * O nó 'no' está em pai->p[idx] e o irmão direito em pai->p[idx+1].
 * A chave separadora (pai->s[idx]) desce para o final de 'no' e a menor chave do irmão
 * direito sobe para o pai. O filho mais à esquerda do irmão passa a ser o filho mais à
 * direita de 'no'.
 */
void redistribui_direita(TNo *pai, int idx, TNo *no, TNo *dir) {
    int i;
    // O separador desce do pai para o final de 'no'
    no->s[no->m] = pai->s[idx];
    no->p[no->m + 1] = dir->p[0];
    if (no->p[no->m + 1] != NULL) {
        no->p[no->m + 1]->pai = no;
    }
    no->m++;
    // A menor chave do irmão direito sobe para o pai
    pai->s[idx] = dir->s[0];
    // Desloca as chaves e ponteiros do irmão direito uma posição à esquerda
    for (i = 0; i < dir->m - 1; i++) {
        dir->s[i] = dir->s[i + 1];
    }
    for (i = 0; i < dir->m; i++) {
        dir->p[i] = dir->p[i + 1];
    }
    dir->p[dir->m] = NULL;
    dir->m--;
}

/*
 * Concatenação (fusão) dos nós pai->p[sep] (esquerda) e pai->p[sep+1] (direita).
 * A chave separadora (pai->s[sep]) desce para o nó da esquerda, seguida de todas as chaves
 * e ponteiros do nó da direita. O nó da direita é liberado e a chave separadora, junto com o
 * ponteiro para o nó da direita, são removidos do pai (que pode, com isso, sofrer underflow).
 */
void concatena(TNo *pai, int sep) {
    int i;
    TNo *esq = pai->p[sep];
    TNo *dir = pai->p[sep + 1];

    // A chave separadora desce para o final do nó da esquerda
    esq->s[esq->m] = pai->s[sep];
    esq->p[esq->m + 1] = dir->p[0];
    if (dir->p[0] != NULL) {
        dir->p[0]->pai = esq;
    }
    // Copia as chaves e ponteiros do nó da direita para o final do nó da esquerda
    int base = esq->m + 1;
    for (i = 0; i < dir->m; i++) {
        esq->s[base + i] = dir->s[i];
        esq->p[base + i + 1] = dir->p[i + 1];
        if (dir->p[i + 1] != NULL) {
            dir->p[i + 1]->pai = esq;
        }
    }
    esq->m = base + dir->m;

    // Remove a chave separadora e o ponteiro para o nó da direita do pai
    for (i = sep; i < pai->m - 1; i++) {
        pai->s[i] = pai->s[i + 1];
    }
    for (i = sep + 1; i < pai->m; i++) {
        pai->p[i] = pai->p[i + 1];
    }
    pai->p[pai->m] = NULL;
    pai->m--;

    free(dir->s);
    free(dir->p);
    free(dir);
}

/*
 * Trata o underflow de 'no' (quando ele fica com menos de d chaves) subindo na árvore.
 * Primeiro tenta redistribuir com um irmão que tenha chaves de sobra (mais de d).
 * Se não for possível, concatena com um irmão; a concatenação pode propagar o underflow
 * para o pai, por isso o processo se repete subindo até a raiz.
 * Retorna o ponteiro para a (possivelmente nova) raiz da árvore.
 */
TNo *trata_underflow(TNo *no, int d) {
    while (no->pai != NULL && no->m < d) {
        TNo *pai = no->pai;

        // Descobre a posição de 'no' entre os filhos do pai
        int idx = 0;
        while (idx <= pai->m && pai->p[idx] != no) {
            idx++;
        }

        TNo *esq = (idx > 0) ? pai->p[idx - 1] : NULL;
        TNo *dir = (idx < pai->m) ? pai->p[idx + 1] : NULL;

        if (esq != NULL && esq->m > d) {        // Irmão esquerdo pode emprestar
            redistribui_esquerda(pai, idx, no, esq);
            break;
        } else if (dir != NULL && dir->m > d) { // Irmão direito pode emprestar
            redistribui_direita(pai, idx, no, dir);
            break;
        } else if (esq != NULL) {               // Concatena com o irmão esquerdo
            concatena(pai, idx - 1);
            no = pai;                           // o underflow pode ter subido para o pai
        } else {                                // Concatena com o irmão direito
            concatena(pai, idx);
            no = pai;
        }
    }

    // Sobe até a raiz
    while (no->pai != NULL) {
        no = no->pai;
    }

    // Se a raiz ficou sem chaves, sua única subárvore vira a nova raiz (a altura diminui).
    // Se a raiz era folha e ficou vazia, a árvore ficou vazia.
    if (no->m == 0) {
        TNo *nova = no->p[0];
        if (nova != NULL) {
            nova->pai = NULL;
        }
        free(no->s);
        free(no->p);
        free(no);
        return nova;
    }

    return no;
}

/*
 * Remove uma chave da árvore B.
 * raiz é o ponteiro para a raiz da árvore e d é a ordem.
 * Se a chave estiver num nó interno, ela é substituída pela sua antecessora (a maior chave
 * da subárvore à esquerda), reduzindo o problema a uma remoção em folha. Após remover da
 * folha, eventuais underflows são tratados por redistribuição ou concatenação.
 * Retorna o ponteiro para a (possivelmente nova) raiz da árvore.
 */
TNo *remove_chave(TNo *raiz, int d, int chave) {
    if (raiz == NULL) {
        return NULL;
    }

    TNo *no = busca(raiz, chave);
    int pos = posicao(chave, no);
    if (pos == no->m || no->s[pos] != chave) { // chave não existe na árvore
        return raiz;
    }

    // Se a chave está num nó interno, troca pela antecessora (maior chave da subárvore esquerda)
    if (!eh_folha(no)) {
        TNo *folha = no->p[pos];
        while (!eh_folha(folha)) {
            folha = folha->p[folha->m];
        }
        no->s[pos] = folha->s[folha->m - 1];
        no = folha;
        pos = folha->m - 1;
    }

    // Remove a chave da folha, deslocando as chaves seguintes para a esquerda
    for (int i = pos; i < no->m - 1; i++) {
        no->s[i] = no->s[i + 1];
    }
    no->m--;

    // Trata o possível underflow subindo na árvore
    return trata_underflow(no, d);
}

/* ===================== Visualização gráfica (SVG) ===================== */

/*
 * Gera uma imagem SVG da árvore (arquivo autocontido, abre direto no navegador).
 * O layout é calculado em uma passada: as folhas são distribuídas da esquerda para a
 * direita e cada nó interno é centralizado sobre seus filhos. As posições de cada nó são
 * guardadas em vetores paralelos (g_nos / g_x / g_y) para depois desenhar arestas e caixas.
 */
#define SVG_CW   38.0   // largura de cada célula (chave) dentro do nó
#define SVG_NH   30.0   // altura do nó
#define SVG_LH   78.0   // distância vertical entre níveis
#define SVG_HGAP 26.0   // espaço horizontal entre folhas vizinhas
#define SVG_MARG 24.0   // margem da figura
#define SVG_MAXN 100000 // máximo de nós suportados no desenho

static TNo *g_nos[SVG_MAXN];
static double g_x[SVG_MAXN]; // canto esquerdo do nó
static double g_y[SVG_MAXN]; // topo do nó
static int g_n;
static double g_cursor;
static int g_d; // ordem da árvore (cada nó tem capacidade para 2d chaves)

// Largura de um nó em pixels: sempre 2d células (capacidade máxima do nó)
static double svg_larg(TNo *no) {
    (void) no;
    return 2.0 * g_d * SVG_CW;
}

/*
 * Calcula recursivamente a posição de cada nó e retorna o x do centro do nó.
 * Folhas avançam um "cursor" horizontal; nós internos ficam centralizados sobre os filhos.
 */
static double svg_layout(TNo *no, int profundidade) {
    double y = SVG_MARG + profundidade * SVG_LH;
    double w = svg_larg(no);
    double centro;

    if (eh_folha(no)) {
        double esquerda = g_cursor;
        g_cursor += w + SVG_HGAP;
        centro = esquerda + w / 2.0;
        g_nos[g_n] = no; g_x[g_n] = esquerda; g_y[g_n] = y; g_n++;
    } else {
        double primeiro = 0, ultimo = 0;
        for (int i = 0; i <= no->m; i++) {
            double c = svg_layout(no->p[i], profundidade + 1);
            if (i == 0) primeiro = c;
            ultimo = c;
        }
        centro = (primeiro + ultimo) / 2.0;
        g_nos[g_n] = no; g_x[g_n] = centro - w / 2.0; g_y[g_n] = y; g_n++;
    }
    return centro;
}

// Retorna o índice de um nó nos vetores de posição (busca linear; as árvores são pequenas)
static int svg_idx(TNo *no) {
    for (int i = 0; i < g_n; i++) {
        if (g_nos[i] == no) return i;
    }
    return -1;
}

// Desenha as arestas (do espaço entre as chaves do pai até o topo de cada filho)
static void svg_arestas(TNo *no, FILE *f) {
    if (eh_folha(no)) return;
    int i = svg_idx(no);
    double left = g_x[i], y = g_y[i];
    for (int k = 0; k <= no->m; k++) {
        TNo *c = no->p[k];
        int ci = svg_idx(c);
        double cx = g_x[ci] + svg_larg(c) / 2.0; // centro do filho
        double slotx = left + k * SVG_CW;        // divisória antes da chave k
        fprintf(f, "  <line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='#888'/>\n",
                slotx, y + SVG_NH, cx, g_y[ci]);
        svg_arestas(c, f);
    }
}

// Desenha as caixas dos nós: sempre 2d células, com as chaves nas primeiras e o restante vazio
static void svg_caixas(TNo *no, FILE *f) {
    int i = svg_idx(no);
    double left = g_x[i], y = g_y[i];
    int folha = eh_folha(no);
    const char *fill = folha ? "#eaf4ff" : "#fff7e6";
    int cap = 2 * g_d; // capacidade do nó

    for (int k = 0; k < cap; k++) {
        double cx = left + k * SVG_CW;
        const char *cellfill = (k < no->m) ? fill : "#fafafa"; // célula vazia em cinza bem claro
        fprintf(f, "  <rect x='%.1f' y='%.1f' width='%.1f' height='%.1f' "
                   "fill='%s' stroke='#bbb'/>\n", cx, y, SVG_CW, SVG_NH, cellfill);
        if (k < no->m) {
            fprintf(f, "  <text x='%.1f' y='%.1f' text-anchor='middle' "
                       "font-family='monospace' font-size='14'>%d</text>\n",
                    cx + SVG_CW / 2.0, y + SVG_NH / 2.0 + 5, no->s[k]);
        }
    }
    // moldura externa do nó (por cima das células)
    fprintf(f, "  <rect x='%.1f' y='%.1f' width='%.1f' height='%.1f' "
               "fill='none' stroke='#333' stroke-width='1.5'/>\n",
            left, y, cap * SVG_CW, SVG_NH);

    if (!folha) {
        for (int k = 0; k <= no->m; k++) {
            svg_caixas(no->p[k], f);
        }
    }
}

void gera_svg(TNo *raiz, int d, const char *arquivo) {
    FILE *f = fopen(arquivo, "w");
    if (f == NULL) {
        printf("Erro ao abrir o arquivo %s para escrita.\n", arquivo);
        return;
    }

    g_n = 0;
    g_cursor = SVG_MARG;
    g_d = d;

    if (raiz != NULL) {
        svg_layout(raiz, 0);
    }

    // Dimensões da figura
    double largura = g_cursor + SVG_MARG;
    double altura = SVG_MARG;
    for (int i = 0; i < g_n; i++) {
        if (g_y[i] + SVG_NH > altura) altura = g_y[i] + SVG_NH;
    }
    altura += SVG_MARG;
    if (largura < 200) largura = 200;

    fprintf(f, "<?xml version='1.0' encoding='UTF-8'?>\n");
    fprintf(f, "<svg xmlns='http://www.w3.org/2000/svg' width='%.0f' height='%.0f' "
               "viewBox='0 0 %.0f %.0f'>\n", largura, altura, largura, altura);
    fprintf(f, "  <rect width='100%%' height='100%%' fill='white'/>\n");

    if (raiz == NULL) {
        fprintf(f, "  <text x='%.1f' y='%.1f' text-anchor='middle' "
                   "font-family='sans-serif' font-size='16' fill='#888'>"
                   "(árvore vazia)</text>\n", largura / 2.0, altura / 2.0);
    } else {
        svg_arestas(raiz, f); // arestas primeiro, para que as caixas fiquem por cima
        svg_caixas(raiz, f);
    }

    fprintf(f, "</svg>\n");
    fclose(f);
}

/*
 * Gera a imagem (SVG) de um passo da execução e acrescenta a referência dela ao
 * arquivo HTML de evolução, com a legenda da operação que produziu o estado atual.
 */
static void salva_passo(TNo *raiz, int d, int passo, const char *rotulo, FILE *html) {
    char nome[64];
    sprintf(nome, "passo_%03d.svg", passo);
    gera_svg(raiz, d, nome);
    if (html != NULL) {
        fprintf(html,
                "  <figure>\n"
                "    <figcaption>Passo %d &mdash; %s</figcaption>\n"
                "    <img src='%s' alt='%s'>\n"
                "  </figure>\n",
                passo, rotulo, nome, rotulo);
    }
}

/* ===================================================================== */

int main(int argc, char *argv[]) {
    TNo *raiz = NULL;

    int d;
    //le ordem da arvore
    printf("Digite a ordem (d) da árvore: ");
    scanf("%d", &d);

    char l[1000];
    char delimitador[] = "-";
    char *ptr;
    int valor;

    /* lê valores para criar a arvore
     * valores devem ser informados separados por traço
     * exemplo: 1-3-5-2-7-9-21-6 */
    printf("\nDigite as chaves a serem inseridas, separadas por traço (sem espaço entre os traços e os valores).\n");
    printf("Exemplo: 1-3-5-2-7-9-21-6\n");

    /* abre o HTML que vai reunir as imagens de cada passo, em sequência */
    int passo = 0;
    char rotulo[64];
    FILE *html = fopen("arvore.html", "w");
    if (html != NULL) {
        fprintf(html,
                "<!DOCTYPE html>\n<html lang='pt-BR'>\n<head>\n"
                "  <meta charset='UTF-8'>\n"
                "  <title>Árvore B (ordem d=%d) &mdash; passo a passo</title>\n"
                "  <style>\n"
                "    body { font-family: sans-serif; margin: 24px; background:#fafafa; color:#222; }\n"
                "    h1 { font-size: 20px; }\n"
                "    figure { margin: 0 0 28px 0; padding: 12px; background:#fff;\n"
                "             border:1px solid #ddd; border-radius:8px; display:inline-block; }\n"
                "    figcaption { font-weight: bold; margin-bottom: 8px; }\n"
                "    img { display:block; max-width:100%%; height:auto; }\n"
                "  </style>\n</head>\n<body>\n"
                "  <h1>Árvore B (ordem d=%d) &mdash; evolução passo a passo</h1>\n",
                d, d);
    }

    scanf("%s", l);
    //quebra a string de entrada
    ptr = strtok(l, delimitador);
    while(ptr != NULL) {
        valor = atoi(ptr);
        printf("\n\n*** Inserindo %d ***\n\n", valor);
        raiz = insere_folha(raiz, d, valor);
        imprime_arvore(raiz, 0);
        passo++;
        sprintf(rotulo, "Inserção de %d", valor);
        salva_passo(raiz, d, passo, rotulo, html);
        ptr = strtok(NULL, delimitador);
    }

    /* lê valores para remover da árvore, no mesmo formato da inserção */
    printf("\n\nDigite as chaves a serem removidas, separadas por traço (ou apenas - para nenhuma).\n");
    printf("Exemplo: 5-2-9\n");

    scanf("%s", l);
    ptr = strtok(l, delimitador);
    while (ptr != NULL) {
        valor = atoi(ptr);
        printf("\n\n*** Removendo %d ***\n\n", valor);
        raiz = remove_chave(raiz, d, valor);
        imprime_arvore(raiz, 0);
        passo++;
        sprintf(rotulo, "Remoção de %d", valor);
        salva_passo(raiz, d, passo, rotulo, html);
        ptr = strtok(NULL, delimitador);
    }

    /* fecha o HTML e informa o resultado */
    if (html != NULL) {
        if (passo == 0) {
            fprintf(html, "  <p>(nenhuma operação realizada)</p>\n");
        }
        fprintf(html, "</body>\n</html>\n");
        fclose(html);
        printf("\n\nGeradas %d imagem(ns) (passo_001.svg ...) e o arquivo 'arvore.html'.\n", passo);
        printf("Abra no navegador (ex.: open arvore.html) para ver a evolução passo a passo.\n");
    }

    libera(raiz, d);
}

