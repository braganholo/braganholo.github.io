/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tutorialarquivosacessorandomico;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vanessa
 */
public class Main {

    /**
     * Cria um arquivo com 5 funcionarios
     */
    private static void criaArquivo(String nomeArquivo) throws IOException {
        RandomAccessFile arquivo = null;

        //Cria uma lista de clientes
        List<Cliente> clientes = null;
        clientes = new ArrayList<Cliente>();
        //Cria 5 clientes
        //Notem que estamos gravando os nomes dos clientes com o mesmo tamanho (6 caracteres), para que possamos
        //navegar no arquivo depois
        Cliente c;
        c = new Cliente(1, "Maria ", "01/01/1980", 1000);
        clientes.add(c);
        c = new Cliente(2, "Carlos", "30/04/1976", 3000);
        clientes.add(c);
        c = new Cliente(3, "Ana   ", "23/05/1980", 5000);
        clientes.add(c);
        c = new Cliente(4, "Rita  ", "01/07/1989", 1500);
        clientes.add(c);
        c = new Cliente(5, "Marcos", "27/04/1975", 7000);
        clientes.add(c);

        try {
            //Se arquivo já existe, apaga
            File f = new File(nomeArquivo);
            if (f.exists()) {
                f.delete();
            }
            //Abre o arquivo para leitura e escrita (rw)           
            arquivo = new RandomAccessFile(f, "rw");
            //Grava os clientes no arquivo
            for (int i = 0; i < clientes.size(); i++) {
                clientes.get(i).salva(arquivo);
            }
        } catch (Exception e) {
        } finally {
            if (arquivo != null) {                
                arquivo.close();
            }
        }
    }

    private static void leArquivo(String nomeArquivo) throws IOException {
        RandomAccessFile arquivo = null;
        try {
            System.out.println("-----------------------------");
            //Abre o arquivo para leitura (r)
            arquivo = new RandomAccessFile(new File(nomeArquivo), "r");
            //Cria uma lista de clientes                        
            List<Cliente> clientes = null;            
            clientes = new ArrayList<Cliente>();
            //Le os clientes do arquivo            
            while (true) {     
                Cliente c = new Cliente();
                c.le(arquivo);
                clientes.add(c);
                System.out.println(c.toString());                
            }
        } catch (Exception e) {
        } finally {
            if (arquivo != null) {
                arquivo.close();
            }
        }
        System.out.println("-----------------------------");
    }

    private static void leSegundoRegistroArquivo(String nomeArquivo) throws IOException {
        RandomAccessFile arquivo = null;
        try {
            //Abre o arquivo para leitura (r)
            arquivo = new RandomAccessFile(new File(nomeArquivo), "r");
            //Le o segundo cliente do arquivo            
            //Como cada registro tem 4 campos, precisamos calcular o número de bytes que vamos avançar
            //A posição para onde vamos avançar é medida em bytes
            //Os campos do registro são 1 Int (4 bytes) + 1 String de 6 caracteres (8 bytes) + 1 String de 10 caracteres (12 bytes) + 1 double (8 bytes)
            //Total: 32 bytes (que é o tamanho que cada registro ocupa, pelas nossas contas)
            arquivo.seek(32);
            Cliente c = new Cliente();
            c.le(arquivo);
            System.out.println("Segundo cliente é: " + c.toString());
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            if (arquivo != null) {
                arquivo.close();
            }
        }
    }

    private static void substituiTerceiroCliente(String nomeArquivo) throws IOException {
        RandomAccessFile arquivo = null;
        try {
            //Abre o arquivo para leitura e escrita (rw)
            arquivo = new RandomAccessFile(new File(nomeArquivo), "rw");
            //Posiciona no terceiro cliente do arquivo
            //Como cada registro tem 32 bytes, vamos pular para a posição 64 do arquivo (= 2 * 32)
            arquivo.seek(64);
            Cliente c = new Cliente();
            c.le(arquivo);
            System.out.println("Terceiro cliente é: " + c.toString());
            //coloca novos valores para este cliente
            c.codCliente = 6;
            c.dataNascimento = "01/01/2001";
            c.nome = "NOVO  ";
            c.salario = 0;
            //salva cliente no arquivo, na posição do terceiro cliente
            //como ele já leu o cliente, o cursor avançou
            //vamos voltar para a posição original do terceiro cliente
            arquivo.seek(64);
            c.salva(arquivo);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            if (arquivo != null) {
                arquivo.close();
            }
        }
        //Agora vamos ler o arquivo todo novamente, para ver como ficou
        leArquivo(nomeArquivo);
    }

    private static void adicionaRegistros(String nomeArquivo) throws IOException {
        RandomAccessFile arquivo = null;

        //Cria uma lista com 2 clientes
        List<Cliente> clientes = null; 
        clientes = new ArrayList<Cliente>();        
        //Cria 2 clientes
        //Notem que estamos gravando os nomes dos clientes com o mesmo tamanho (6 caracteres), para que possamos
        //navegar no arquivo depois
        Cliente c;
        c = new Cliente(7, "Marta ", "01/01/1970", 1000);
        clientes.add(c);
        c = new Cliente(8, "Jose  ", "12/05/1976", 2000);
        clientes.add(c);

        try {
            //Abre o arquivo para leitura e escrita (rw)
            arquivo = new RandomAccessFile(new File(nomeArquivo), "rw");
            //Antes de gravar, posiciona cursor no final do arquivo
            long pos = arquivo.length();
            arquivo.seek(pos);
            //Grava os clientes no arquivo
            for (int i = 0; i < clientes.size(); i++) {
                clientes.get(i).salva(arquivo);
            }            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (arquivo != null) {
                System.out.println("Tamanho do arquivo é " + arquivo.length() + " bytes");                
                arquivo.close();
            }
        }
        //Agora vamos ler o arquivo todo novamente, para ver como ficou
        leArquivo(nomeArquivo);
    }

    /*
     * @param nomeArquivo nome do arquivo
     * @param pos posicao onde será gravado um novo registro de cliente
     * @param cli Cliente que será gravado no arquivo na posição pos
     */
    private static void gravaClientePos(String nomeArquivo, int pos, Cliente c) throws IOException {
        RandomAccessFile arquivo = null;
         
        try {
            //Abre o arquivo para leitura e escrita (rw)
            arquivo = new RandomAccessFile(new File(nomeArquivo), "rw");            
            //posiciona o cursor no endereço da posição passada como paramentro
            arquivo.seek((pos-1)*32);
            c.salva(arquivo);  
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (arquivo != null) {
                System.out.println("Tamanho do arquivo é " + arquivo.length() + " bytes");
                arquivo.close();
            }
        }
        //Agora vamos ler o arquivo todo novamente, para ver como ficou
        leArquivo(nomeArquivo);        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        criaArquivo("arquivo.dat");
        leArquivo("arquivo.dat");
        leSegundoRegistroArquivo("arquivo.dat");
        substituiTerceiroCliente("arquivo.dat");
        adicionaRegistros("arquivo.dat");
        
        criaArquivo("arquivo2.dat");
        Cliente cli = new Cliente(6, "Vania ", "10/04/1977", 2000);
        gravaClientePos("arquivo2.dat", 7, cli);
        System.out.println("Notem que aparentemente ele pulou 2 registros ao invés de 1, mas não é bem isso que está acontecendo. Isso é devido ao tamanho variável das strings, já que não há uma string de 6 posições gravada no espaço que sobrou entre um registro e outro. Vamos agora gravar um novo registro no espaço que sobrou, para ver como vai ficar");
        cli = new Cliente(7,"Xavier", "01/01/1920", 1000);
        gravaClientePos("arquivo2.dat", 6, cli);

    }
}
