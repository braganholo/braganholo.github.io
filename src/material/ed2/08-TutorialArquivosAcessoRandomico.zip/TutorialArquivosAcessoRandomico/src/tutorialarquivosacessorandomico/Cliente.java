/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tutorialarquivosacessorandomico;

/**
 *
 * @author vanessa
 */
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author vanessa
 */
public class Cliente {

    public int codCliente;
    public String nome;    
    public String dataNascimento;
    public double salario;

    /**
     *
     * Construtor vazio
     */
    public Cliente() {
    }

    /**
     *
     * Construtor com todos os atributos do objeto
     */
    public Cliente(int codCliente, String nome, String dataNascimento, double salario) {
        this.codCliente = codCliente;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.salario = salario;
    }

    /**
     *
     * Salva um Cliente no arquivo, na posição atual do cursor
     */
    public void salva(RandomAccessFile out) throws IOException {
        out.writeInt(codCliente);
        out.writeUTF(nome);
        out.writeUTF(dataNascimento);
        out.writeDouble(salario);
        System.out.println("Gravação do cliente de código " + codCliente + " realizada com sucesso");        
    }

    /**
     *
     * Lê um Cliente do arquivo, na posição atual do cursor
     */
    public void le(RandomAccessFile in) throws IOException {
        codCliente = in.readInt();
        nome = in.readUTF();
        dataNascimento = in.readUTF();
        salario = in.readDouble();
    }

    @Override
    public String toString() {
        return this.codCliente + ", " + this.nome + ", " + this.dataNascimento + ", " + this.salario;
    }
}

