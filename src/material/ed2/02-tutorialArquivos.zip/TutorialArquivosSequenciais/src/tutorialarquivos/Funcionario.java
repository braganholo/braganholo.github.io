/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tutorialarquivos;

/**
 *
 * @author vanessa
 */
public class Funcionario {
    public int codFuncionario;
    public String nome;
    public String cpf;
    public String dataNascimento;
    public float salario;
}
