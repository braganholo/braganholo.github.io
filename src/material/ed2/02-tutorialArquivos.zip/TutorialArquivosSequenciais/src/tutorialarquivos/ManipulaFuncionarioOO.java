/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tutorialarquivos;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vanessa
 */
public class ManipulaFuncionarioOO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        //Declara o outputStream
        DataOutputStream out = null;
        //cria uma lista de funcionários
        List<FuncionarioOO> funcs = null;
        funcs = new ArrayList<FuncionarioOO>();
        
        //objeto para manipular Funcionário
        FuncionarioOO f;
        
        //Cria o primeiro funcionário e o adiciona na lista de funcionários
        f = new FuncionarioOO(1, "012.345.678-90", "Maria", "01/01/1980", 1000);
        funcs.add(f);
        //Cria o segundo funcionário e o adiciona na lista de funcionários
        f = new FuncionarioOO(2, "234.567.890-12", "Carlos", "30/04/1976", 3000);
        funcs.add(f);

        try {
            System.out.println("Abrindo arquivo Funcionario.dat para gravação...");
            //passando true no FileOutputStrem, novos registros são adicionados ao arquivo, caso ele já exista
            out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("funcionario.dat", true)));
            System.out.println("Gravando dados no arquivo Funcionario.dat ...");
            funcs.get(0).salva(out);
            funcs.get(1).salva(out);        
        } finally {
            System.out.println("Fechando arquivo Funcionario.dat ...");
            if (out != null)
                out.close();
        }
        //Trecho para ler os dados
        //Declara o InputStream
        DataInputStream in = null;
        //Zera a lista de funcionários
        funcs = new ArrayList<FuncionarioOO>();        
        try {
            System.out.println("Abrindo arquivo Funcionario.dat para leitura...");
            in = new DataInputStream(new BufferedInputStream(new FileInputStream("funcionario.dat")));
            System.out.println("Lendos os dados do arquivo Funcionario.dat ...");

            while (true) {
                f = new FuncionarioOO();
                f.le(in);
                f.imprime();
                funcs.add(f);
                System.out.println();                
            }

        } catch (EOFException e) {
            //arquivo terminou
        } finally {
            System.out.println("Fechando arquivo Funcionario.dat ...");
            if (in != null)
                in.close();
        }
        System.out.println("Total de " + funcs.size() + " funcionários lidos!");
    }
}
