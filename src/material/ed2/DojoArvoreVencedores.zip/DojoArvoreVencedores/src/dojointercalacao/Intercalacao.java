/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dojointercalacao;

import java.io.File;
import java.util.List;

/**
     * Executa o algoritmo da Árvore dos Vencedores
     * @param nomeParticoes array com os nomes dos arquivos que contêm as partições de entrada
     * @param nomeArquivoSaida nome do arquivo de saída resultante da execução do algoritmo
     */
public class Intercalacao {

    public void executa(List<String> nomeParticoes, String nomeArquivoSaida) throws Exception {

            //TODO: Inserir aqui o código do algoritmo de Árvore de Vencedores

    }

}
