#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "intercalacao.h"

void intercalacao(char **nome_particoes, int qtd, char *nome_arquivo_saida)
{
	//TODO: Inserir aqui o codigo do algoritmo de Arvore de Vencedores
}