package dojobalanceline;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

public class BalanceLine {
    /**
     * Executa o algoritmo Balance Line
     * @param nomeArquivoMestre arquivo mestre
     * @param nomeArquivoTransacao arquivo de transação
     * @param nomeArquivoErros arquivo de erros
     * @param nomeArquivoSaida arquivo de saída
     */
    public void executa(String nomeArquivoMestre, String nomeArquivoTransacao,
            String nomeArquivoSaida, String nomeArquivoErros) throws Exception {
        
            //TODO: Inserir aqui o código do algoritmo balanceLine        


    }
}