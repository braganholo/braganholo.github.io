#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <limits.h>

#include "chave_secundaria.h"


void indexa(char *nome_arquivo, int tam)
{
//TODO: Inserir aqui o codigo do algoritmo
}
